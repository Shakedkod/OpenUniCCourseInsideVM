#ifndef CONSTANTS_H
#define CONSTANTS_H

typedef enum 
{
    FALSE,
    TRUE
} Bool;

#endif