#ifndef USER_INTERFACE_H
#define USER_INTERFACE_H

#include "coms.h"

code execute_line(vars variables, boolean *is_eof);

#endif