#ifndef STRING_MANIPULATION_H
#define STRING_MANIPULATION_H

#include "coms.h"

boolean is_all_whitespaces(const char *str);
code strcmp_for_commands(const char *a, const char *b);

#endif